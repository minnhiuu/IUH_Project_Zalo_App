export { cssInterop } from 'nativewind';
